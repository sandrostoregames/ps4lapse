PayLoader3
==========

blah blah blah

HOWTO
=====

1. Set firmware version in Makefile
2. Compile with "./build.sh"
3. Copy pkg file to usb stick
4. Install pkg on PS3


Notes
=====
1. Loading ps3load after the payload will execute the appropriate ps3load.self, after your self exits you will be returned to the XMB.
2. Loading 'ethdebug' will load ArielX's Kammy self, after it executes you will be returned to the XMB.
3. Loading 'ethdebug/ps3load' will load ethdebug, then ps3load.

